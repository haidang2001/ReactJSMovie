Thành viên: 
	51900306 - Nguyễn Cao Hải Đăng
	51900332 - Nguyễn Trọng Hiển
Cách chạy chương trình:
	- Điều kiện tiên quyết: có NodeJS, nếu chưa có thì tải qua link này: https://nodejs.org/en/
	- Các bước chạy chương trình trong local 
		Bước 1: Mở terminal với đường dẫn chứa file hiện tại 
		Bước 2: Thực hiện tải các file npm cần thiết để chạy chương trình với câu lệnh: 
			npm install hoặc npm i 
		Bước 3: Chạy chương trình trong local bằng câu lệnh: npm start, 
			lúc này chương trình sẽ được chạy trên http://localhost:3000/ 
