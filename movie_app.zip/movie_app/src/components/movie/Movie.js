import React, { useEffect, useState } from 'react';
import MovieDetail from '../moviedetail/MovieDetail';

const FEATURED_API ="https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=d65576ff8c623925ca8cfb1cfd60e5ac&page=1";
const SEARCH_API = "https://api.themoviedb.org/3/search/movie?&api_key=d65576ff8c623925ca8cfb1cfd60e5ac&query=";

export function Movie() {
	const [movies, setMovies] = useState([]);
	const [searchTerm, setSearchTerm] = useState('');

	const getMovies = (API) => {
		fetch(API)
		.then((res) => res.json())
		.then((data) => {
			// console.log(data);
			setMovies(data.results);
		});
	}

	useEffect(() =>{ 
		getMovies(FEATURED_API);
	},[])

	const handleOnChange = (e )=> {
		setSearchTerm(e.target.value);
		if(searchTerm){
			getMovies(SEARCH_API+searchTerm);
		}
	}

	return (
		<>
			<header>
				<input className="search" type="text" placeholder="Search..." 
					value={searchTerm} onChange={handleOnChange}/>
			</header>
			<div className="movie-container" >
				{movies.length > 0 && movies.map(movie =>(
					<MovieDetail key={movie.id} {...movie} />
				))}
			</div>
		</>
	);
}

